#ifndef DAIRYMILKBUBBLY_H
#define DAIRYMILKBUBBLY_H

#include "AeratedChocolate.h"

class DairyMilkBubbly : public AeratedChocolate {
	DairyMilkBubbly(string m, int cubic);
};

#endif