#include "MilkyBar.h"

/*MilkyBar :: MilkyBar(string m, bool slab) {
	Chocolate(m, 8, slab);
} */