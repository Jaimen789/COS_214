#include "DairyMilk.h"

/*DairyMilk :: DairyMilk(string m, bool slab) {
	Chocolate(m, 12, slab);
}*/