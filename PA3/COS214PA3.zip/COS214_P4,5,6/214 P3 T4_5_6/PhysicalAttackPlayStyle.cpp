#include "PhysicalAttackPlayStyle.h"

string PhysicalAttackPlayStyle :: attack() {
    return "is using physical ability to attack.";
}