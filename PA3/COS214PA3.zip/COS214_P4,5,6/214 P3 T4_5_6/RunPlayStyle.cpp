#include "RunPlayStyle.h"

string RunPlayStyle :: attack() {
    return "decides life is better than death and leaves the battle.";
}