#ifndef PLAYSTYLE_H
#define PLAYSTYLE_H

#include <string>
#include <iostream>
#include <cmath>

using namespace std;

class PlayStyle {
public:
    virtual string attack() = 0;
};

#endif