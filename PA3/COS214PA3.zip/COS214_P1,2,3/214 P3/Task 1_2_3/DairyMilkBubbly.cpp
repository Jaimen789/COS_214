#include "DairyMilkBubbly.h"

/*DairyMilkBubbly :: DairyMilkBubbly(string m, int cubic) {
	AeratedChocolate(m, 9, cubic);
}*/