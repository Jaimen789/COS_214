#include "Areo.h"

/*Areo :: Areo(string m, int cubic) {
	AeratedChocolate(m, 5, cubic);
} */