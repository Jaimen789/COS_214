#include "Lindor.h"

/*Lindor :: Lindor(string m, bool slab) {
	Chocolate(m, 15, slab);
}*/