#ifndef PHYSICALATTACKPLAYSTYLE_H
#define PHYSICALATTACKPLAYSTYLE_H

#include "PlayStyle.h"

class PhysicalAttackPlayStyle : public PlayStyle {
public:
    string attack();
};

#endif